CREATE TABLE `wp_nf_objects` (  `id` bigint(20) NOT NULL AUTO_INCREMENT,  `type` varchar(255) NOT NULL,  PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_nf_objects` DISABLE KEYS */;
INSERT INTO `wp_nf_objects` VALUES('1', 'form');
INSERT INTO `wp_nf_objects` VALUES('2', 'notification');
INSERT INTO `wp_nf_objects` VALUES('3', 'notification');
INSERT INTO `wp_nf_objects` VALUES('4', 'notification');
/*!40000 ALTER TABLE `wp_nf_objects` ENABLE KEYS */;
